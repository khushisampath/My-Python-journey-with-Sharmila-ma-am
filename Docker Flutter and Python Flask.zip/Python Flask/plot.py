import matplotlib
matplotlib.use("Agg")  # Safe non-GUI backend for servers

from flask import Flask, Response
import matplotlib.pyplot as plt
import io, random, webbrowser
from threading import Timer

app = Flask(__name__)

@app.route('/')
def home():
    return (
        "Simple Flask Data Dashboard<br><br>"
        "Use:<br>"
        "/plot — to view a random data chart"
    )

@app.route('/plot')
def plot():
    x = list(range(1, 10))
    y = [random.randint(10, 100) for _ in x]

    fig = plt.figure()
    plt.plot(x, y, marker='o')
    plt.title("Random Data Plot")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    plt.close(fig)
    buf.seek(0)
    return Response(buf.getvalue(), mimetype='image/png')

def open_browser():
    webbrowser.open_new("http://127.0.0.1:5004/")

if __name__ == '__main__':
    # Auto-open the browser 1s after server starts (optional)
    Timer(1, open_browser).start()
    app.run(debug=True, port=5004)
